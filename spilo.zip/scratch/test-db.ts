import { PrismaClient } from "@prisma/client";
import { PrismaMariaDb } from "@prisma/adapter-mariadb";
import "dotenv/config";

async function test() {
  const connectionString = process.env.DATABASE_URL || "mysql://root:@127.0.0.1:3306/spilo_db";
  const adapter = new PrismaMariaDb(connectionString);
  const prisma = new PrismaClient({ adapter });

  console.log("Testing connection with string config...");
  const brands = await prisma.brand.findMany();
  console.log("SUCCESS! BRANDS FROM MYSQL:", brands);

  await prisma.$disconnect();
}

test().catch(console.error);
