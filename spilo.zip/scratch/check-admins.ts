import { PrismaClient } from "@prisma/client";
import { PrismaMariaDb } from "@prisma/adapter-mariadb";
import "dotenv/config";

async function checkAdmins() {
  const connectionString = process.env.DATABASE_URL || "mysql://root:@127.0.0.1:3306/spilo_db";
  const adapter = new PrismaMariaDb(connectionString);
  const prisma = new PrismaClient({ adapter });

  const admins = await prisma.adminUser.findMany();
  console.log("ALL ADMINS IN MYSQL:", JSON.stringify(admins, null, 2));

  await prisma.$disconnect();
}

checkAdmins().catch(console.error);
