"use client";

import { Suspense, useState, useEffect, useMemo } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { 
  Search, 
  ChevronRight, 
  ChevronDown, 
  ChevronUp, 
  SlidersHorizontal,
  ArrowUpDown,
  RotateCcw,
  Tag,
  Check
} from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { dataService } from "@/services/dataService";
import { Product } from "@/types";

import { useCatalogFilters, ABSOLUTE_MAX_PRICE } from "@/hooks/useCatalogFilters";

const COLOR_OPTIONS = [
  { id: "ნაცრისფერი", label: "ნაცრისფერი", hex: "#9CA3AF" },
  { id: "შავი", label: "შავი", hex: "#111827" },
  { id: "თეთრი", label: "თეთრი", hex: "#FFFFFF" },
  { id: "Natural Titanium", label: "Natural Titanium", hex: "#C5C1B8" },
  { id: "Space Black", label: "Space Black", hex: "#1F2937" },
  { id: "ბეჟი", label: "ბეჟი", hex: "#F5F5DC" },
];

const STORAGE_OPTIONS = ["128GB", "256GB", "512GB", "1TB", "22GB"];

function CatalogContent() {
  const {
    filters,
    activeFiltersCount: hookActiveCount,
    toggleBrand,
    toggleCategory,
    setPriceRange,
    setSort,
    toggleDiscountedOnly,
    resetFilters: resetHookFilters,
  } = useCatalogFilters();

  // Products State synced with dataService
  const [productsList, setProductsList] = useState<Product[]>([]);

  useEffect(() => {
    setProductsList(dataService.getProducts());
    const unsub = dataService.subscribe(() => {
      setProductsList(dataService.getProducts());
    });
    return () => unsub();
  }, []);

  // UI Specific State (colors, storage, open accordions)
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedStorage, setSelectedStorage] = useState<string[]>([]);
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Accordion Toggles
  const [priceOpen, setPriceOpen] = useState(true);
  const [brandOpen, setBrandOpen] = useState(true);
  const [categoryOpen, setCategoryOpen] = useState(true);
  const [colorOpen, setColorOpen] = useState(true);
  const [storageOpen, setStorageOpen] = useState(true);

  // Dynamic Brand & Category counts
  const brandCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    productsList.forEach((p: Product) => {
      if (p.brandName) counts[p.brandName] = (counts[p.brandName] || 0) + 1;
    });
    return counts;
  }, [productsList]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    productsList.forEach((p: Product) => {
      if (p.categoryName) counts[p.categoryName] = (counts[p.categoryName] || 0) + 1;
    });
    return counts;
  }, [productsList]);

  // Dynamic colors from products & palette
  const dynamicColors = useMemo(() => {
    const foundColors = new Set<string>();
    productsList.forEach((p) => {
      p.variants?.forEach((v) => {
        if (v.type === "color") {
          v.options.forEach((opt) => foundColors.add(opt.label));
        }
      });
      p.specs?.forEach((sg) => {
        sg.items.forEach((item) => {
          if (item.label.toLowerCase().includes("ფერ") || item.label.toLowerCase().includes("color")) {
            foundColors.add(item.value);
          }
        });
      });
    });

    const list = [...COLOR_OPTIONS];
    foundColors.forEach((fc) => {
      if (fc && !list.some((c) => c.label.toLowerCase() === fc.toLowerCase())) {
        list.push({ id: fc, label: fc, hex: "#6366F1" });
      }
    });
    return list;
  }, [productsList]);

  // Dynamic storage options from products
  const dynamicStorageOptions = useMemo(() => {
    const foundStorage = new Set<string>(STORAGE_OPTIONS);
    productsList.forEach((p) => {
      p.specs?.forEach((sg) => {
        sg.items.forEach((item) => {
          if (item.label.toLowerCase().includes("მეხსიერება") || item.label.toLowerCase().includes("storage") || item.label.toLowerCase().includes("rom")) {
            foundStorage.add(item.value);
          }
        });
      });
    });
    return Array.from(foundStorage);
  }, [productsList]);

  const handleColorToggle = (color: string) => {
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]
    );
  };

  const handleStorageToggle = (storage: string) => {
    setSelectedStorage((prev) =>
      prev.includes(storage) ? prev.filter((s) => s !== storage) : [...prev, storage]
    );
  };

  const handleMinPriceChange = (val: number) => {
    const newMin = Math.min(val, filters.maxPrice - 50);
    setPriceRange(Math.max(0, newMin), filters.maxPrice);
  };

  const handleMaxPriceChange = (val: number) => {
    const newMax = Math.max(val, filters.minPrice + 50);
    setPriceRange(filters.minPrice, Math.min(ABSOLUTE_MAX_PRICE, newMax));
  };

  const resetFilters = () => {
    resetHookFilters();
    setSelectedColors([]);
    setSelectedStorage([]);
  };

  const activeFiltersCount = hookActiveCount + selectedColors.length + selectedStorage.length;

  // Main Filter Logic
  const filteredProducts = useMemo(() => {
    return productsList.filter((product: Product) => {
      // Search query
      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const matchesQuery =
          product.title.toLowerCase().includes(q) ||
          product.brandName.toLowerCase().includes(q) ||
          product.categoryName.toLowerCase().includes(q) ||
          product.sku.toLowerCase().includes(q);
        if (!matchesQuery) return false;
      }

      // Price filter
      const effectivePrice = product.discountPrice || product.price;
      if (effectivePrice < filters.minPrice || effectivePrice > filters.maxPrice) return false;

      // Brand filter
      if (filters.brand.length > 0) {
        const matchesBrand = filters.brand.some(
          (b) => product.brandName.toLowerCase() === b.toLowerCase() || product.brandId.toLowerCase() === b.toLowerCase()
        );
        if (!matchesBrand) return false;
      }

      // Category filter
      if (filters.category.length > 0) {
        const matchesCategory = filters.category.some(
          (c) =>
            product.categoryName.toLowerCase().includes(c.toLowerCase()) ||
            product.categoryId.toLowerCase().includes(c.toLowerCase())
        );
        if (!matchesCategory) return false;
      }

      // Color filter
      if (selectedColors.length > 0 && product.colorName && !selectedColors.includes(product.colorName))
        return false;

      // Storage filter
      if (selectedStorage.length > 0 && product.storage && !selectedStorage.includes(product.storage))
        return false;

      // Discount filter
      if (filters.onlyDiscounted && !product.discountPrice) return false;

      return true;
    }).sort((a: Product, b: Product) => {
      const priceA = a.discountPrice || a.price;
      const priceB = b.discountPrice || b.price;
      if (filters.sort === "price-asc") return priceA - priceB;
      if (filters.sort === "price-desc") return priceB - priceA;
      if (filters.sort === "name-asc") return a.title.localeCompare(b.title, "ka");
      if (filters.sort === "name-desc") return b.title.localeCompare(a.title, "ka");
      return 0;
    });
  }, [
    productsList,
    filters,
    selectedColors,
    selectedStorage,
  ]);

  // Dual Slider Math
  const minPercent = (filters.minPrice / ABSOLUTE_MAX_PRICE) * 100;
  const maxPercent = (filters.maxPrice / ABSOLUTE_MAX_PRICE) * 100;

  return (
    <div className="container mx-auto px-4 lg:px-6 max-w-[1600px] space-y-8">
      {/* Top Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-gray-200/80">
        <div>
          <h1 className="text-2xl md:text-3xl text-gray-900 tracking-tight flex items-center gap-2">
            <span>კატალოგი & კატეგორიები</span>
          </h1>
          <p className="text-xs md:text-sm text-gray-500 mt-1">
            სულ მოიძებნა <span className="text-gray-900">{filteredProducts.length}</span> პროდუქტი
          </p>
        </div>

        {/* Sort & Mobile Filter Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
            className="lg:hidden flex items-center gap-2 bg-white px-3.5 py-2.5 rounded-xl text-xs text-gray-700 shadow-[0_8px_30px_rgb(0,0,0,0.015)] cursor-pointer border border-gray-100"
          >
            <SlidersHorizontal className="w-4 h-4 text-blue-600" />
            <span>ფილტრები ({activeFiltersCount})</span>
          </button>

          {/* Clean Sort Dropdown Pill */}
          <div className="relative">
            <button
              onClick={() => setIsSortDropdownOpen(!isSortDropdownOpen)}
              onBlur={() => setTimeout(() => setIsSortDropdownOpen(false), 200)}
              className="flex items-center gap-2 bg-white px-3.5 py-2 rounded-xl text-xs text-gray-700 shadow-[0_8px_30px_rgb(0,0,0,0.015)] cursor-pointer select-none border border-transparent hover:border-gray-200/60 transition-all"
            >
              <ArrowUpDown className="w-4 h-4 text-gray-400" />
              <span className="text-gray-900">
                {filters.sort === "default" && "სორტირება"}
                {filters.sort === "all" && "ყველა"}
                {filters.sort === "price-desc" && "ფასი: კლებადობით"}
                {filters.sort === "price-asc" && "ფასი: ზრდადობით"}
                {filters.sort === "name-asc" && "დასახელება: A-Z"}
                {filters.sort === "name-desc" && "დასახელება: Z-A"}
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-gray-400 ml-0.5 transition-transform duration-200 ${
                  isSortDropdownOpen ? "rotate-180" : ""
                }`}
              />
            </button>

            {isSortDropdownOpen && (
              <div className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 min-w-[200px] z-30 space-y-0.5">
                {[
                  { id: "all", label: "ყველა" },
                  { id: "price-desc", label: "ფასი: კლებადობით" },
                  { id: "price-asc", label: "ფასი: ზრდადობით" },
                  { id: "name-asc", label: "დასახელება: A-Z" },
                  { id: "name-desc", label: "დასახელება: Z-A" },
                ].map((opt) => {
                  const isSelected = filters.sort === opt.id;

                  return (
                    <div
                      key={opt.id}
                      onClick={() => {
                        setSort(opt.id);
                        setIsSortDropdownOpen(false);
                      }}
                      className={`flex items-center justify-between px-3.5 py-2 text-xs cursor-pointer transition-colors ${
                        isSelected ? "bg-blue-50/80 text-blue-700" : "text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <span>{opt.label}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Catalog Layout */}
      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Left Filter Sidebar */}
        <aside
          className={`w-full lg:w-[320px] shrink-0 bg-white rounded-2xl p-6 md:p-7 shadow-[0_8px_30px_rgb(0,0,0,0.015)] space-y-6 ${
            isMobileFilterOpen ? "block" : "hidden lg:block"
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-gray-100">
            <div className="flex items-center gap-2 text-sm text-gray-900">
              <SlidersHorizontal className="w-4 h-4 text-blue-600" />
              <span>ფილტრაცია</span>
              {activeFiltersCount > 0 && (
                <span className="bg-blue-50 text-blue-600 text-[11px] px-2 py-0.5 rounded-full">
                  {activeFiltersCount}
                </span>
              )}
            </div>

            {activeFiltersCount > 0 && (
              <button
                onClick={resetFilters}
                className="text-xs text-blue-600 hover:text-blue-800 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>გასუფთავება</span>
              </button>
            )}
          </div>

          {/* Dual-Thumb Price Slider Section */}
          <div className="space-y-4 pb-5 border-b border-gray-100">
            <button
              onClick={() => setPriceOpen(!priceOpen)}
              className="w-full flex items-center justify-between text-xs text-gray-900 cursor-pointer"
            >
              <span>ფასის ინტერვალი (₾)</span>
              {priceOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {priceOpen && (
              <div className="space-y-4 pt-1">
                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100 focus-within:border-blue-500 transition-colors">
                    <span className="text-[10px] text-gray-400 block">დან</span>
                    <div className="flex items-center justify-between pt-0.5">
                      <input
                        type="number"
                        min={0}
                        max={filters.maxPrice - 50}
                        value={filters.minPrice}
                        onChange={(e) => handleMinPriceChange(Number(e.target.value))}
                        className="w-full bg-transparent text-gray-900 focus:outline-none text-xs"
                      />
                      <span className="text-gray-400 text-xs shrink-0">₾</span>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100 focus-within:border-blue-500 transition-colors">
                    <span className="text-[10px] text-gray-400 block">მდე</span>
                    <div className="flex items-center justify-between pt-0.5">
                      <input
                        type="number"
                        min={filters.minPrice + 50}
                        max={ABSOLUTE_MAX_PRICE}
                        value={filters.maxPrice}
                        onChange={(e) => handleMaxPriceChange(Number(e.target.value))}
                        className="w-full bg-transparent text-gray-900 focus:outline-none text-xs"
                      />
                      <span className="text-gray-400 text-xs shrink-0">₾</span>
                    </div>
                  </div>
                </div>

                <div className="relative py-3">
                  <div className="h-2 bg-gray-100 rounded-full relative w-full overflow-hidden">
                    <div
                      className="absolute h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                      style={{
                        left: `${minPercent}%`,
                        width: `${maxPercent - minPercent}%`,
                      }}
                    />
                  </div>

                  <input
                    type="range"
                    min={0}
                    max={ABSOLUTE_MAX_PRICE}
                    step={25}
                    value={filters.minPrice}
                    onChange={(e) => handleMinPriceChange(Number(e.target.value))}
                    className="absolute top-1/2 -translate-y-1/2 w-full appearance-none bg-transparent pointer-events-none cursor-pointer [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-blue-600 [&::-webkit-slider-thumb]:shadow-[0_4px_12px_rgba(37,99,235,0.3)] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:hover:scale-110 [&::-webkit-slider-thumb]:transition-transform"
                  />

                  <input
                    type="range"
                    min={0}
                    max={ABSOLUTE_MAX_PRICE}
                    step={25}
                    value={filters.maxPrice}
                    onChange={(e) => handleMaxPriceChange(Number(e.target.value))}
                    className="absolute top-1/2 -translate-y-1/2 w-full appearance-none bg-transparent pointer-events-none cursor-pointer [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-blue-600 [&::-webkit-slider-thumb]:shadow-[0_4px_12px_rgba(37,99,235,0.3)] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:hover:scale-110 [&::-webkit-slider-thumb]:transition-transform"
                  />
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[
                    { label: "0 - 500 ₾", min: 0, max: 500 },
                    { label: "500 - 1500 ₾", min: 500, max: 1500 },
                    { label: "1500 - 3500 ₾", min: 1500, max: 3500 },
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setPriceRange(preset.min, preset.max);
                      }}
                      className={`text-[11px] px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                        filters.minPrice === preset.min && filters.maxPrice === preset.max
                          ? "bg-blue-50 text-blue-700 border border-blue-200"
                          : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Brand Filter */}
          <div className="space-y-3 pb-5 border-b border-gray-100">
            <button
              onClick={() => setBrandOpen(!brandOpen)}
              className="w-full flex items-center justify-between text-xs text-gray-900 cursor-pointer"
            >
              <span>ბრენდი</span>
              {brandOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {brandOpen && (
              <div className="space-y-2.5 pt-1 text-xs text-gray-700 max-h-48 overflow-y-auto pr-1">
                {Object.entries(brandCounts).map(([brand, count]) => {
                  const isChecked = filters.brand.some(
                    (b) => b.toLowerCase() === brand.toLowerCase()
                  );

                  return (
                    <div
                      key={brand}
                      onClick={() => toggleBrand(brand)}
                      className="flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-5 h-5 rounded-lg flex items-center justify-center transition-all ${
                            isChecked
                              ? "bg-blue-600 border border-blue-600 text-white shadow-[0_4px_12px_rgba(37,99,235,0.2)]"
                              : "bg-gray-50 border border-gray-200 group-hover:border-blue-400"
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <span className="group-hover:text-gray-900 transition-colors">{brand}</span>
                      </div>
                      <span className="text-[11px] text-gray-400">({count})</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Category Filter */}
          <div className="space-y-3 pb-5 border-b border-gray-100">
            <button
              onClick={() => setCategoryOpen(!categoryOpen)}
              className="w-full flex items-center justify-between text-xs text-gray-900 cursor-pointer"
            >
              <span>კატეგორია</span>
              {categoryOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {categoryOpen && (
              <div className="space-y-2.5 pt-1 text-xs text-gray-700 max-h-48 overflow-y-auto pr-1">
                {Object.entries(categoryCounts).map(([cat, count]) => {
                  const isChecked = filters.category.some(
                    (c) => c.toLowerCase() === cat.toLowerCase()
                  );

                  return (
                    <div
                      key={cat}
                      onClick={() => toggleCategory(cat)}
                      className="flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-5 h-5 rounded-lg flex items-center justify-center transition-all ${
                            isChecked
                              ? "bg-blue-600 border border-blue-600 text-white shadow-[0_4px_12px_rgba(37,99,235,0.2)]"
                              : "bg-gray-50 border border-gray-200 group-hover:border-blue-400"
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <span className="group-hover:text-gray-900 transition-colors">{cat}</span>
                      </div>
                      <span className="text-[11px] text-gray-400">({count})</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Color Selector */}
          <div className="space-y-3 pb-5 border-b border-gray-100">
            <button
              onClick={() => setColorOpen(!colorOpen)}
              className="w-full flex items-center justify-between text-xs text-gray-900 cursor-pointer"
            >
              <span>ფერი</span>
              {colorOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {colorOpen && (
              <div className="flex items-center gap-2.5 pt-1 flex-wrap">
                {dynamicColors.map((c) => {
                  const isSelected = selectedColors.includes(c.id);

                  return (
                    <button
                      key={c.id}
                      onClick={() => handleColorToggle(c.id)}
                      title={c.label}
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer border ${
                        isSelected
                          ? "ring-2 ring-blue-600 border-white shadow-xs"
                          : "border-gray-200 hover:scale-105"
                      }`}
                      style={{ backgroundColor: c.hex }}
                    >
                      {isSelected && (
                        <Check className={`w-4 h-4 ${c.id === "თეთრი" ? "text-gray-900" : "text-white"}`} />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Storage Option Pills */}
          <div className="space-y-3 pb-5 border-b border-gray-100">
            <button
              onClick={() => setStorageOpen(!storageOpen)}
              className="w-full flex items-center justify-between text-xs text-gray-900 cursor-pointer"
            >
              <span>შიდა მეხსიერება</span>
              {storageOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>

            {storageOpen && (
              <div className="grid grid-cols-2 gap-2 pt-1">
                {dynamicStorageOptions.map((s) => {
                  const isSelected = selectedStorage.includes(s);

                  return (
                    <button
                      key={s}
                      onClick={() => handleStorageToggle(s)}
                      className={`py-2 px-3 rounded-xl text-xs transition-all cursor-pointer text-center ${
                        isSelected
                          ? "bg-blue-600 text-white shadow-[0_4px_12px_rgba(37,99,235,0.2)]"
                          : "bg-gray-50 text-gray-700 hover:bg-gray-100 border border-gray-100"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Toggle Switch: Discounted Only */}
          <div
            onClick={toggleDiscountedOnly}
            className="flex items-center justify-between pt-1 text-xs text-gray-900 cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-red-500" />
              <span>მხოლოდ ფასდაკლებული</span>
            </div>

            <div
              className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                filters.onlyDiscounted ? "bg-blue-600" : "bg-gray-200 group-hover:bg-gray-300"
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  filters.onlyDiscounted ? "translate-x-4" : ""
                }`}
              />
            </div>
          </div>
        </aside>

        {/* Right Product Grid */}
        <main className="flex-1 w-full space-y-6">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  title={product.title}
                  price={product.price}
                  discountPrice={product.discountPrice}
                  monthlyInstallment={product.monthlyInstallment}
                  image={product.images[0]}
                  discountPercentage={product.discountPercentage}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center space-y-4 max-w-lg mx-auto shadow-[0_8px_30px_rgb(0,0,0,0.015)] my-8">
              <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                <Search className="w-8 h-8" />
              </div>
              <h2 className="text-lg md:text-xl text-gray-900">
                არჩეული ფილტრებით ნივთი ვერ მოიძებნა
              </h2>
              <p className="text-xs md:text-sm text-gray-500">
                სცადეთ ფილტრების გასუფთავება.
              </p>
              <div className="pt-2">
                <button
                  onClick={resetFilters}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-xl transition-colors cursor-pointer"
                >
                  ფილტრების გასუფთავება
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default function CatalogPage() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans pb-24">
      {/* Top Breadcrumbs */}
      <div className="py-3.5 bg-white border-b border-gray-100 mb-8">
        <div className="container mx-auto px-4 lg:px-6 max-w-[1600px]">
          <nav className="flex items-center gap-2 text-xs text-gray-500">
            <Link href="/" className="hover:text-blue-600 transition-colors">
              მთავარი
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span className="text-gray-900">კატალოგი</span>
          </nav>
        </div>
      </div>

      <main>
        <Suspense
          fallback={
            <div className="container mx-auto px-4 py-12 text-center text-gray-400 text-sm">
              იტვირთება კატალოგი...
            </div>
          }
        >
          <CatalogContent />
        </Suspense>
      </main>
    </div>
  );
}
